package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

@Repository("pilotDao")
@Transactional
public class PilotDaoImpl implements IPilotDao{
	@PersistenceContext
	private EntityManager em;

	@Override
	public void savePilot(Pilot pilot) {
		em.persist(pilot);
		
		
	}
	@Override
	public List<Pilot> getPilotDetails() {
		List<Pilot> pilotList=em.createQuery("from Pilot").getResultList();
		return pilotList;
	}
	@Override
	public void deletePilot(Integer pilotId) {
		Pilot pilot=em.find(Pilot.class, pilotId);
		if(pilot!=null) {
			em.remove(pilot);
	}

}
	@Override
	public Pilot updatePilot(Integer pilotId,Pilot p) {
		
		Pilot findPilot=getPiotById(pilotId);
		findPilot.setFirstName(p.getFirstName());
		findPilot.setLastName(p.getLastName());
		findPilot.setAddress(p.getAddress());
		
		findPilot.setCities(p.getCities());
		findPilot.setEmail(p.getEmail());
		findPilot.setGender(p.getGender());
		findPilot.setMaxCrusing(p.getMaxCrusing());
		findPilot.setDateOfJoing(p.getDateOfJoing());
		findPilot.setQualification(p.getQualification());
		//em.merge(findPilot);
			return findPilot;
		
		
	
	}
	@Override
	public Pilot getPiotById(Integer pilotId) {
		Pilot pilot=em.find(Pilot.class, pilotId);
		return pilot;
	}
}