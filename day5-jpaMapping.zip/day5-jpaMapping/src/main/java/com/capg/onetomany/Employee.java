package com.capg.onetomany;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {
	@Id
	private Integer empId;
	private String empName;
	@ManyToOne
	@JoinColumn(name="CompanyFK")
	private Company company;

	public Employee() {
		super();
	}

	public Employee(Integer empId, String empName, Company company) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.company = company;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", company=" + company + "]";
	}

	

}
