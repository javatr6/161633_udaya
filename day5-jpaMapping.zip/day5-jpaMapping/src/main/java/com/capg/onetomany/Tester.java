package com.capg.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Tester {
	public static void main(String []args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		Company zoho=new Company("Zoho");
		Company adp=new Company("ADP");
		
		Employee employee=new Employee(1001,"Udaya",zoho);
		Employee employee2=new Employee(1002,"Chocolate",adp);
		Employee employee3=new Employee(1003,"Biscuit",adp);
		
		entityManager.persist(zoho);
		entityManager.persist(adp);
		entityManager.persist(employee);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		transaction.commit();
		entityManager.close();
	}

}
