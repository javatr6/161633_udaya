package com.cap.manytomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Tester {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		Events html= new Events();
		html.setEvent_id(1);
		html.setEvent_name("HTML");
		Events oracle = new Events(2,"ORACLE");
		Events java = new Events(3,"JAVA");
		
		Delegates jerry=new Delegates(1001,"Jerry");
		Delegates doremon=new Delegates(1002,"Doremon");
		Delegates nobitha=new Delegates(1003,"Nobitha");
		Delegates picachu=new Delegates(1004,"Picachu");
		
		jerry.getEvents().add(html);
		jerry.getEvents().add(oracle);
		jerry.getEvents().add(java);
		
		doremon.getEvents().add(oracle);
		doremon.getEvents().add(html);
		
		nobitha.getEvents().add(java);
		
		picachu.getEvents().add(html);
		entityManager.persist(html);
		entityManager.persist(oracle);
		entityManager.persist(java);
		entityManager.persist(jerry);
		entityManager.persist(doremon);
		entityManager.persist(nobitha);
		entityManager.persist(picachu);
		
		transaction.commit();
		entityManager.close();
	}

}
