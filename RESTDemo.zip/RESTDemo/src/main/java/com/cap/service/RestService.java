package com.cap.service;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.HttpMethod;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cap.dao.IProductDao;
import com.cap.dao.ProductDaoImpl;
@Path("/api")
public class RestService {
	IProductDao productDao=new ProductDaoImpl();
	@GET
	@Path("/products")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getAllProducts(){
		List<Product> products = productDao.getAllProducts();
		return products;
	}
	
	@POST
	@Path("addproducts")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> addProducts(@FormParam("productId") Integer productId,@FormParam("productName") String productName){
		List<Product> products = productDao.addProducts(productId,productName);
		return products;
	}
	@PUT
	@Path("findproducts/{productId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Product findProducts(@PathParam("productId") Integer productId){
		Product products = productDao.findProducts(productId);
		return products;
	}
	@DELETE
	@Path("/delproducts/{productId}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> delProducts(@PathParam("productId") Integer productId){
		List<Product> products = productDao.delProducts(productId);
		return products;
	}
	@POST
	@Path("updateproducts/{productId}/{productName}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> updateProducts(@PathParam("productId") Integer productId,@PathParam("productName")String productName){
		List<Product> products = productDao.updateProducts(productId,productName);
		return products;
	}
	@GET
	@Path("/saymessage")
	public String message() {
		return "Welcome to REST services..";
	}
	@GET
	@Path("/greet/{userName}")
	@Produces(MediaType.TEXT_HTML)
	public String greetUser(@PathParam("userName")String myUser) {
		return "<h1 style='color:red'>hey hello..</h1>"+myUser;
		
	}
	@GET
	@Path("/loaddata")
	@Produces(MediaType.TEXT_XML)
	public String getXml() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+"<employee>"
				+"<name>Udaya</name>"
				+"</employee>";
	}
	
	@GET
	@Path("/loadjson")
	@Produces(MediaType.APPLICATION_JSON)
	public String getJSon() {
		return "{"
				+ "\"firstname\":\"tom\","
				+ "\"lastname\":\"jerry\""
				+ "}";
	}
}
