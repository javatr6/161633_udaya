package com.cap.dao;

import java.util.List;

import com.cap.service.Product;

public interface IProductDao {
	public abstract List<Product> getAllProducts();
	public abstract List<Product> delProducts(Integer productId);
	public abstract Product findProducts(Integer productId);
	public abstract List<Product> addProducts(Integer productId, String productName);
	public abstract List<Product> updateProducts(Integer productId, String productName);
	
}
