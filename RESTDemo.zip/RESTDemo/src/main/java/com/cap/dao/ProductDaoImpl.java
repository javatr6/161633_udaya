package com.cap.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cap.service.Product;

public class ProductDaoImpl implements IProductDao {
	private static List<Product> products=dummyDB();
	
	

	private static List<Product> dummyDB() {
		List<Product> products=new ArrayList<>();
		products.add(new Product(1,"Apple XS"));
		products.add(new Product(2,"Samsung"));
		return products;
	}




	public List<Product> getAllProducts() {
		
		return products;
	}




	@Override
	public List<Product> delProducts(Integer productId) {
		Iterator<Product> iterator = products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId().equals(productId)) {
				iterator.remove();
				break;
				
			}
		}
		return products;
	}




	@Override
	public Product findProducts(Integer productId) {
		Iterator<Product> iterator = products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId().equals(productId)) {
				
				return product;
				
			}
		}
		return null;
	}




	@Override
	public List<Product> addProducts(Integer productId, String productName) {
			products.add(new Product(productId,productName));
		return products;
	}






	@Override
	public List<Product> updateProducts(Integer productId, String productName) {
		Iterator<Product> iterator = products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId().equals(productId)) {
				product.setProductName(productName);
				break;
				
			}
		}
		return products;
	}




	
}
