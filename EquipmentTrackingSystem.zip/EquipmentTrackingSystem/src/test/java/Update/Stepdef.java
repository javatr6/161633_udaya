package Update;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	@Given("^userType and location$")
	public void usertype_and_location() throws Throwable {
	    
	}

	@When("^userType is valid$")
	public void usertype_is_valid() throws Throwable {
	   
	}

	@When("^location is valid$")
	public void location_is_valid() throws Throwable {
	    
	}

	@When("^End date is valid$")
	public void end_date_is_valid() throws Throwable {
	    
	}

	@Then("^display message$")
	public void display_message() throws Throwable {
	    
	}

	@Given("^userType$")
	public void usertype() throws Throwable {
	    
	}

	@Given("^required equipment record$")
	public void required_equipment_record() throws Throwable {
	    
	}

	@When("^equipment is  in in_state$")
	public void equipment_is_in_in_state() throws Throwable {
	    
	}

	@Then("^user can perform modify$")
	public void user_can_perform_modify() throws Throwable {
	}

	@When("^equipment is  in retired$")
	public void equipment_is_in_retired() throws Throwable {
	   
	}

	@Then("^user can perform comment$")
	public void user_can_perform_comment() throws Throwable {
	    
	}

	@When("^equipment is  in unassociated$")
	public void equipment_is_in_unassociated() throws Throwable {
	   
	}

	@Then("^user can perform in_stock$")
	public void user_can_perform_in_stock() throws Throwable {
	   
	}

	@Given("^multiple data for the equipment$")
	public void multiple_data_for_the_equipment() throws Throwable {
	    
	}

	@When("^user is valid$")
	public void user_is_valid() throws Throwable {
	   
	}

	@When("^system is valid$")
	public void system_is_valid() throws Throwable {
	   
	}

	@Then("^system should allow to update multiple data$")
	public void system_should_allow_to_update_multiple_data() throws Throwable {
	    
	}

	@Given("^User Transactions$")
	public void user_Transactions() throws Throwable {
	   
	}

	@Given("^Equipment status$")
	public void equipment_status() throws Throwable {
	    
	}

	@When("^Purchase_Method$")
	public void purchase_method() throws Throwable {
	    
	}

	@When("^required$")
	public void required() throws Throwable {
	   
	}

	@Then("^update the field$")
	public void update_the_field() throws Throwable {
	   
	}

	@When("^Seq_Number$")
	public void seq_number() throws Throwable {
	   
	}

	@When("^User_Id$")
	public void user_id() throws Throwable {
	   
	}

	@When("^Department_Id$")
	public void department_id() throws Throwable {
	    
	}

	@When("^Use_Status$")
	public void use_status() throws Throwable {
	   
	}

	@When("^Cost_Center$")
	public void cost_center() throws Throwable {
	    
	}

	@When("^Install_Date$")
	public void install_date() throws Throwable {
	   
	}

	@When("^Location$")
	public void location() throws Throwable {
	    
	}

	@When("^Audit_Indicator$")
	public void audit_indicator() throws Throwable {
	   
	}

	@When("^Audit_Date$")
	public void audit_date() throws Throwable {
	    
	}

	@When("^Comments$")
	public void comments() throws Throwable {
	    
	}

	@When("^Stock_Location$")
	public void stock_location() throws Throwable {
	   
	}

	@Given("^specified data in an equipment$")
	public void specified_data_in_an_equipment() throws Throwable {
	   
	}

	@Then("^system should allow to update data from external systems$")
	public void system_should_allow_to_update_data_from_external_systems() throws Throwable {
	    
	}

}
