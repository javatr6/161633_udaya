package loginWithWebDriver;


import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private WebDriver driver;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\uvelagal\\Desktop\\selinium\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	@Given("^open login page$")
	public void open_login_page() throws Throwable {
		driver.get("http://localhost:8081/BusPassRequest/pages/index1.html?");
		String title=driver.getTitle();
		assertEquals("Bus Portal",title);
	
	
	}

	@Given("^userdetails$")
	public void userdetails() throws Throwable {
		driver.findElement(By.name("username")).sendKeys("Udaya");
		driver.findElement(By.name("password")).sendKeys("udaya123");
	}

	@When("^submit validate details$")
	public void submit_validate_details() throws Throwable {
		WebElement login=driver.findElement(By.name("login"));
		login.submit();
		
	}

	@Then("^redirect to menu page$")
	public void redirect_to_menu_page() throws Throwable {
		driver.navigate().to("http://localhost:8081/BusPassRequest/pages/menu.html");
	}
	@After
	public void tearDown() {
		driver.quit();
	}
}
