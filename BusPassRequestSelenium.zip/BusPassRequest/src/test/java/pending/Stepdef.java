package pending;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private WebDriver driver;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\uvelagal\\Desktop\\selinium\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	@Given("^Open the web browser$")
	public void open_the_web_browser() throws Throwable {
		driver.get("http://localhost:8081/BusPassRequest/pages/index1.html?");
	}

	@Given("^enter valid  username   enter valid password$")
	public void enter_valid_username_enter_valid_password() throws Throwable {
		driver.findElement(By.name("username")).sendKeys("Udaya");
		driver.findElement(By.name("password")).sendKeys("udaya123");
	}

	@Given("^navigate to menu page$")
	public void navigate_to_menu_page() throws Throwable {
		driver.navigate().to("http://localhost:8081/BusPassRequest/pages/menu.html");
	}

	@Given("^click on  Pending request$")
	public void click_on_Pending_request() throws Throwable {
		driver.findElement(By.linkText("Pending")).click();
	}

	@Given("^click on see request$")
	public void click_on_see_request() throws Throwable {
		driver.switchTo().frame("myiframe");
		driver.findElement(By.xpath("/html/body/input[1]")).click();
	}

	@Given("^fill his request$")
	public void fill_his_request() throws Throwable {
		driver.findElement(By.name("routeno")).sendKeys("1");
		driver.findElement(By.name("totalkm")).sendKeys("10");
		driver.findElement(By.name("totalfare")).sendKeys("3500");
		
	}

	@When("^click on approve request$")
	public void click_on_approve_request() throws Throwable {
		driver.findElement(By.xpath("/html/body/input[4]")).click();
	}

	@Then("^show approve message$")
	public void show_approve_message() throws Throwable {
		String expected = driver.findElement(By.xpath("/html/body/h1")).getText();
		System.out.println(expected);
		String actual="Hey!! your request for bus pass is approved...";
		assertEquals(expected, actual);
	}
	@After
	public void tearDown() {
		driver.quit();
	}

}
