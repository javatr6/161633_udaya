package login;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.cap.dao.ILoginDAO;
import org.cap.model.LoginBean;
import org.cap.service.ILoginService;
import org.cap.service.LoginServiceImpl;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private String username;
	private String password;
	private boolean flag;
	private ILoginService loginService;
	private LoginBean login=new LoginBean();
	
	@Before
	public void setUp() {
		
		
		MockitoAnnotations.initMocks(this);
		
		loginService=new LoginServiceImpl();
	}
	
	@Then("^redirect to menu page$")
	public void redirect_to_menu_page() throws Throwable {
	   if(this.flag==true) {
		   System.out.println("Success");
	   }
	}
	@Given("^userdetails$")
	public void userdetails() throws Throwable {
		login=new LoginBean("Udaya","udaya123");
		assertNotNull(login);
	}


	
@When("^for valid user with username and password$")
public void for_valid_user_with_username_and_password() throws Throwable {
	
	this.flag=loginService.checkUser(this.login);
	   
	assertTrue(flag);
	 
}



}
