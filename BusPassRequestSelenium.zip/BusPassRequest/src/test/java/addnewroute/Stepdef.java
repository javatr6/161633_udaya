package addnewroute;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private WebDriver driver;
	private WebElement element;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\uvelagal\\Desktop\\selinium\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	@Given("^routepath,total seat,occupied seat,bus no,driver name,total km$")
	public void routepath_total_seat_occupied_seat_bus_no_driver_name_total_km() throws Throwable {
		 driver.get("http://localhost:8082/BusPassRequest/pages/addroute.html");
		   driver.findElement(By.xpath("//*[@id=\"subject\"]")).sendKeys("Chennai-Tambaram");
		    driver.findElement(By.name("occupiedseats")).sendKeys("2");
		 driver.findElement(By.name("totalseats")).sendKeys("50");
		   
		    driver.findElement(By.name("busno")).sendKeys("TN-2345");
		   driver.findElement(By.name("drivername")).sendKeys("arimdam");
		    driver.findElement(By.name("totalkm")).sendKeys("59");
		    Thread.sleep(3000);
	}

	@When("^Add routes after taking inputs$")
	public void add_routes_after_taking_inputs() throws Throwable {
		element=driver.findElement(By.name("addroute"));
		
	      element.submit();
	      Thread.sleep(5000); 
		
	}

	@Then("^go to success page$")
	public void go_to_success_page() throws Throwable {
		 driver.navigate().to("http://localhost:8082/BusPassRequest/pages/addSuccess.html");
	}
	@After
	public void teardown() {
		driver.quit();
	}

}
