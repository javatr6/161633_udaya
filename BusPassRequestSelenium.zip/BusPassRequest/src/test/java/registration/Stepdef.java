package registration;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private WebDriver driver;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\uvelagal\\Desktop\\selinium\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	@Given("^open buspass registration page$")
	public void open_buspass_registration_page() throws Throwable {
		driver.get("http://localhost:8082/BusPassRequest/pages/requestform.html");
		//String title=driver.getTitle();
		//assertEquals("Bus Portal",title);
	}

	@Given("^details of the user$")
	public void details_of_the_user() throws Throwable {
		driver.findElement(By.name("empid")).sendKeys("1616_FS");
		driver.findElement(By.name("fname")).sendKeys("Uday");
		driver.findElement(By.name("lname")).sendKeys("Uday");
		driver.findElement(By.name("emailid")).sendKeys("Uday@gmail.com");
		driver.findElement(By.id("female")).click();
		
		WebElement mySelectElement = driver.findElement(By.name("designation"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Manager");
		driver.findElement(By.name("address")).sendKeys("Ahmadabad");
		 WebElement dateBox = driver.findElement(By.name("doj"));
		 dateBox.sendKeys("11282018");
		 WebElement myLocSelect = driver.findElement(By.name("location"));
			Select dropdownLoc= new Select(myLocSelect);
			dropdownLoc.selectByVisibleText("Chennai MIPL");
			WebElement myPicLocSelect = driver.findElement(By.name("pickuplocation"));
			Select dropdownPicLoc= new Select(myPicLocSelect);
			dropdownPicLoc.selectByVisibleText("Parnur");
			WebElement timeBox = driver.findElement(By.name("pickuptime"));
			 timeBox.sendKeys("0245PM");
			 
	}

	@When("^submit after details entered$")
	public void submit_after_details_entered() throws Throwable {
		WebElement submitBtn=driver.findElement(By.name("submit"));
		submitBtn.submit();
	}

	@Then("^redirect to successfulpage$")
	public void redirect_to_successfulpage() throws Throwable {
		driver.navigate().to("http://localhost:8081/BusPassRequest/pages/request.html");
	}
	@After
	public void tearDown() {
		//driver.quit();
	}
}
