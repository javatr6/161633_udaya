package monthlyreport;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
private	WebDriver driver;

	
	@Before
public void setUp() {
	System.setProperty("webdriver.chrome.driver",
			"C:\\Users\\uvelagal\\Desktop\\selinium\\chromedriver.exe");
	driver=new ChromeDriver();
}
	
	@Given("^Open the web browser$")
	public void open_the_web_browser() throws Throwable {
		driver.get("http://localhost:8081/BusPassRequest/pages/index1.html?");
	}

	@Given("^enter valid  username   enter valid password$")
	public void enter_valid_username_enter_valid_password() throws Throwable {
		driver.findElement(By.name("username")).sendKeys("Udaya");
		driver.findElement(By.name("password")).sendKeys("udaya123");
	}

	@Given("^navigate to menu page$")
	public void navigate_to_menu_page() throws Throwable {
		driver.navigate().to("http://localhost:8081/BusPassRequest/pages/menu.html");
	}

	@Given("^click on montly report$")
	public void click_on_montly_report() throws Throwable {
		driver.findElement(By.linkText("Monthly Report")).click();
	}

	@Given("^select from and to date$")
	public void select_from_and_to_date() throws Throwable {
		driver.switchTo().frame("myiframe");
		driver.findElement(By.name("fdate")).sendKeys("09/08/2018");
		driver.findElement(By.name("tdate")).sendKeys("29/11/2018");
	}

	@When("^click on submit button$")
	public void click_on_submit_button() throws Throwable {
		driver.findElement(By.name("generate")).click();
	}

	@Then("^show all monthly report$")
	public void show_all_monthly_report() throws Throwable {
		Thread.sleep(5000);
		driver.close();
	}
}
