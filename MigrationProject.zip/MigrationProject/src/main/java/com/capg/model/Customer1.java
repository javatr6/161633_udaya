 package com.capg.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
		public class Customer1 {
			@Id
			@GeneratedValue
			private int custId;
			private String firstName;
			private String lastName;
			private Double regFee;
			private LocalDate purDate;
			public Customer1() {
				super();
			}
			
			public Customer1(String firstName, String lastName, Double regFee, LocalDate purDate) {
				super();
				
				this.firstName = firstName;
				this.lastName = lastName;
				this.regFee = regFee;
				this.purDate = purDate;
			}

			public LocalDate getPurDate() {
				return purDate;
			}

			public void setPurDate(LocalDate purDate) {
				this.purDate = purDate;
			}

			public Customer1(String firstName, String lastName, Double regFee) {
				super();
				this.firstName = firstName;
				this.lastName = lastName;
				this.regFee = regFee;
			}

			public Customer1(int custId, String firstName, String lastName, Double regFee) {
				super();
				this.custId = custId;
				this.firstName = firstName;
				this.lastName = lastName;
				this.regFee = regFee;
			}
			public int getCustId() {
				return custId;
			}
			public void setCustId(int custId) {
				this.custId = custId;
			}
			public String getFirstName() {
				return firstName;
			}
			public void setFirstName(String firstName) {
				this.firstName = firstName;
			}
			public String getLastName() {
				return lastName;
			}
			public void setLastName(String lastName) {
				this.lastName = lastName;
			}
			public Double getRegFee() {
				return regFee;
			}
			public void setRegFee(Double regFee) {
				this.regFee = regFee;
			}
			@Override
			public String toString() {
				return "Customer1 [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", regFee="
						+ regFee + "]";
			}
			

		} 
		 



