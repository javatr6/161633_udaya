package com.capg.model;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Tester {
	public static void main(String args[]) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		Customer1 cust1=new Customer1("Udaya","Lakshmi",20000.00,LocalDate.of(2017, 3, 24));
		Address address1=new Address("Hyd",cust1);
		
		Customer1 cust2=new Customer1("Sha","Mon",10000.00,LocalDate.now());
		Address address2=new Address("Delhi",cust2);
		
		entityManager.persist(cust1);
		entityManager.persist(address1);
		
		
		entityManager.persist(cust2);
		entityManager.persist(address2);
		
		transaction.commit();
		entityManager.close();
		
	}
	}


