 
		package com.capg.model;

		import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
		import javax.persistence.JoinColumn;
		import javax.persistence.OneToOne;

		@Entity
		public class Address {
			@Id

			
		@GeneratedValue
			private int addressId;
			public Address(String address, Customer1 customer) {
				super();
				this.address = address;
				this.customer = customer;
			}





			private String address;
			@OneToOne
			@JoinColumn(name="cusfk")
			private Customer1 customer;
			
			
			
			
			
			public Address() {
				super();
			}





			public Address(int addressId, String address, Customer1 customer) {
				super();
				this.addressId = addressId;
				this.address = address;
				this.customer = customer;
			}





			public int getAddressId() {
				return addressId;
			}





			public void setAddressId(int addressId) {
				this.addressId = addressId;
			}





			public String getAddress() {
				return address;
			}





			public void setAddress(String address) {
				this.address = address;
			}





			public Customer1 getCustomer() {
				return customer;
			}





			public void setCustomer(Customer1 customer) {
				this.customer = customer;
			}





			@Override
			public String toString() {
				return "Address [addressId=" + addressId + ", address=" + address + ", customer=" + customer + "]";
			}
			
			
			
			
			

		} 
		 



